- We will be using 'cover' template for the home page
- We will be using 'Jumbotron' template for the about us page
- 'Corousel' template for the category page

  - Category 1: Books
    - there must be 5 books
      - How to read a person like book
      - Why nations?
      - Your next Moves - Patrick Bet David
      - How to lead when you’re not in charge
      - it ends with us 1
  - Category 2: Electronic
    - there must 5 electronics
      - Iphone 15 pro max
      - Surface Pro
      - Mac Book Pro
      - Appple Pencil
      - Watch
- We will use button for the pages but we will create 2 or 3 index.html pertaining to the other web pages and link it to the main index.html

  - does the button have to be clikable? how do you want me to do it?
    - if not, all the pages will be in the same page regardless of where people clicks
- Flow up with the professor about the headings: whether it should be clikable or not?
- or how do they want us to do it.

- Bishal:
- I tried to push my code to this project, but it was not accepting, so I uploaded my files in the main branch. I am off to work now, but I'll text you once I have chance. Text me if you have any questions.
- 
